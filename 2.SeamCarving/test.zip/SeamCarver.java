import edu.princeton.cs.algs4.Picture;
import edu.princeton.cs.algs4.StdOut;
// import java.awt.Color;

public class SeamCarver {
   private Picture pictureObject;
   private double[][] energyMatrix;
   private double[][] cumulatedMatrix;
   private double[][] parentMatrix;

   public SeamCarver(Picture picture) {                // create a seam carver object based on the given picture
      pictureObject = new Picture(picture);
      energyMatrix = new double[width()][height()];
      cumulatedMatrix = new double[width()][height()];
      // for (int x = 0; x < width(); x++)
      //   for (int y = 0; y < height(); y++) {
      //     energyMatrix[x][y] = energy(x, y);
      //     cumulatedMatrix[x][y] = Double.MAX_VALUE;
      //   }

      // for (int y = 0; y < height(); y++) {
      //   StdOut.println(energyMatrix[y][1]);
      //   cumulatedMatrix[y][0] = energy(0, y);
      // }
        // StdOut.println("hy");

      // PRINTS the computed Energy matrix
      // for (double[]row:energyMatrix) {
      //   for (double num: row)
      //     StdOut.print(String.format("%.2f", num) + " ");
      //     // StdOut.print(" ");
      //   StdOut.println();
      // }


      // PRINTS the initialized cumulated matrix
      // for (double[]row:cumulatedMatrix) {
      //   for (double num: row)
      //     StdOut.print(String.format("%.2f", num) + " ");
      //     // StdOut.print(" ");
      //   StdOut.println();
      // }




   }
   // helper function to compute energy of a pixel, computes for x values
   private double deltaX(int x, int y) {
      // get colors from pixel on the right
      int red1 = pictureObject.get(x + 1, y).getRed();
      int green1 = pictureObject.get(x + 1, y).getGreen();
      int blue1 = pictureObject.get(x + 1, y).getBlue();
      // get colors from pixel on the left
      int red2 = pictureObject.get(x - 1, y).getRed();
      int green2 = pictureObject.get(x - 1, y).getGreen();
      int blue2 = pictureObject.get(x - 1, y).getBlue();

      return Math.pow((green2 - green1), 2) + Math.pow((red2 - red1), 2) + Math.pow((blue2 - blue1), 2);    
   }
   // helper function to compute energy of a pixel, computes for y values
   private double deltaY(int x, int y) {
      // get colors from pixel below
      int red1 = pictureObject.get(x, y + 1).getRed();
      int green1 = pictureObject.get(x, y + 1).getGreen();
      int blue1 = pictureObject.get(x, y + 1).getBlue();
      // get colors from pixel ontop
      int red2 = pictureObject.get(x, y - 1).getRed();
      int green2 = pictureObject.get(x, y - 1).getGreen();
      int blue2 = pictureObject.get(x, y - 1).getBlue();

      return Math.pow((green2 - green1), 2) + Math.pow((red2 - red1), 2) + Math.pow((blue2 - blue1), 2);
   }

   public Picture picture() {                       // current picture
        return pictureObject;
   }

   public     int width() {                         // width of current picture
      return pictureObject.width();
   }

   public     int height() {                        // height of current picture
      return pictureObject.height();
   }

   public  double energy(int x, int y) {             // energy of pixel at column x and row y
      if (x < 0 || y < 0) throw new IndexOutOfBoundsException();
      if (x > width() - 1 || y > height() - 1) throw new IndexOutOfBoundsException(x + " " + y);
      if (x == width() - 1 || y == height() - 1) return 1000;
      if (x == 0 || y == 0) return 1000;
      //get delta x
      double deltaX = deltaX(x, y);
      double deltaY = deltaY(x, y);
      return Math.sqrt(deltaX + deltaY);
   }
   public   int[] findHorizontalSeam() {              // sequence of indices for horizontal seam
      return new int[1];
   }
   public   int[] findVerticalSeam() {                // sequence of indices for vertical seam
      return new int[1];
   }
   public    void removeHorizontalSeam(int[] seam) {   // remove horizontal seam from current picture

   }
   public    void removeVerticalSeam(int[] seam) {    // remove vertical seam from current picture

   }
   public static void main(String[] args) {
      // Picture pic = new Picture("6x5.png");
      // SeamCarver sm = new SeamCarver(pic);
      // StdOut.println(Double.MAX_VALUE);
      // StdOut.println(sm.energy(1, 2));
      // int green = pic.get(0, 0).getGreen();
      // StdOut.println(green);
      // StdOut.println(sm.width());
      // StdOut.println(sm.height());
   }



}



